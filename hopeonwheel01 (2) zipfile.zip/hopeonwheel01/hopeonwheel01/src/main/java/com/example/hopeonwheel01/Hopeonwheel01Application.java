package com.example.hopeonwheel01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hopeonwheel01Application {

	public static void main(String[] args) {
		SpringApplication.run(Hopeonwheel01Application.class, args);
	}

}
