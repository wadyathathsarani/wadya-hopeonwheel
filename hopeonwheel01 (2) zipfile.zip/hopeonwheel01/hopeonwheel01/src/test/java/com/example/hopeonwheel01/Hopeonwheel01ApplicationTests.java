package com.example.hopeonwheel01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hopeonwheel01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
